<?php
$VancoClientid = 'ESnnnnn';                          // Replace with client ID for organization API calls will be made for
$VancoUserid = 'EnnnnnWS';                           // Replace with user ID provided by Vanco for API calls
$VancoPassword = '';                         // Replace with password provided by Vanco for API calls
$VancoEnc_key = '';  // Replace with encryption key value provided by Vanco for API calls
$VancoUrltoredirect = RedirectURL("CatchCreatePayment.php");; // Replace with the URL your customer's browser will be redirected to after making a TransparentRedirect API call
$VancoTest = False;                                   // Set to true when running in Vanco's test environment. Change to false when running in production
?>
