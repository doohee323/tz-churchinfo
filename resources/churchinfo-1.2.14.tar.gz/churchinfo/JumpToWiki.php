<script language="javascript" type="text/javascript">
	window.open('http://www.churchdb.org/dokuwiki-2007-06-26b/doku.php','ChurchInfo Wiki Documentation','')
	history.go (-1);
</script>
